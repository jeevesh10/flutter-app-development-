import 'package:flutter/material.dart';

class PrivacySettingsPage extends StatefulWidget {
  @override
  _PrivacySettingsPageState createState() => _PrivacySettingsPageState();
}

class _PrivacySettingsPageState extends State<PrivacySettingsPage> {
  bool isProfilePublic = true;
  bool isLocationAccessEnabled = false;
  bool isMessageFromAnyone = false;
  bool isAnalyticsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Privacy Settings")),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text("Public Profile"),
            subtitle: Text("Allow others to view your profile"),
            value: isProfilePublic,
            onChanged: (value) {
              setState(() {
                isProfilePublic = value;
              });
            },
          ),
          SwitchListTile(
            title: Text("Location Access"),
            subtitle: Text("Allow access to your location"),
            value: isLocationAccessEnabled,
            onChanged: (value) {
              setState(() {
                isLocationAccessEnabled = value;
              });
            },
          ),
          SwitchListTile(
            title: Text("Messages from Anyone"),
            subtitle: Text("Allow messages from people who aren’t contacts"),
            value: isMessageFromAnyone,
            onChanged: (value) {
              setState(() {
                isMessageFromAnyone = value;
              });
            },
          ),
          SwitchListTile(
            title: Text("Enable Analytics"),
            subtitle: Text("Allow app to collect usage data"),
            value: isAnalyticsEnabled,
            onChanged: (value) {
              setState(() {
                isAnalyticsEnabled = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
