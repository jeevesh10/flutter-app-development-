import 'package:flutter/material.dart';

class InAppNotificationSettingsPage extends StatefulWidget {
  @override
  _InAppNotificationSettingsPageState createState() => _InAppNotificationSettingsPageState();
}

class _InAppNotificationSettingsPageState extends State<InAppNotificationSettingsPage> {
  bool showMessageNotifications = true;
  bool showFriendRequestNotifications = true;
  bool showAppUpdatesNotifications = false;
  bool showMentionsNotifications = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("In-App Notification Settings")),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          // Message Notifications
          SwitchListTile(
            title: Text("Message Notifications"),
            subtitle: Text("Receive notifications for new messages"),
            value: showMessageNotifications,
            onChanged: (value) {
              setState(() {
                showMessageNotifications = value;
              });
            },
          ),
          Divider(),

          // Friend Request Notifications
          SwitchListTile(
            title: Text("Friend Request Notifications"),
            subtitle: Text("Receive notifications for new friend requests"),
            value: showFriendRequestNotifications,
            onChanged: (value) {
              setState(() {
                showFriendRequestNotifications = value;
              });
            },
          ),
          Divider(),

          // App Updates Notifications
          SwitchListTile(
            title: Text("App Updates"),
            subtitle: Text("Receive notifications for app updates"),
            value: showAppUpdatesNotifications,
            onChanged: (value) {
              setState(() {
                showAppUpdatesNotifications = value;
              });
            },
          ),
          Divider(),

          // Mentions Notifications
          SwitchListTile(
            title: Text("Mentions"),
            subtitle: Text("Receive notifications when someone mentions you"),
            value: showMentionsNotifications,
            onChanged: (value) {
              setState(() {
                showMentionsNotifications = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
