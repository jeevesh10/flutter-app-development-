import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(ColorBreakGame());
}

class ColorBreakGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Color Break Game',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: GamePage(),
    );
  }
}

class GamePage extends StatefulWidget {
  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  static double ballY = 0;  // Initial vertical position of the ball
  double time = 0;
  double height = 0;
  double initialHeight = ballY;
  bool gameHasStarted = false;
  int score = 0;
  Color ballColor = Colors.blue;  // Initial color of the ball
  List<Color> colors = [Colors.blue, Colors.red, Colors.green, Colors.yellow];
  double obstacleX = 2;  // Position of the obstacle
  Color obstacleColor = Colors.blue;  // Initial color of the obstacle

  // This function makes the ball jump when the screen is tapped
  void jump() {
    setState(() {
      time = 0;
      initialHeight = ballY;
    });
  }

  // This function starts the game and manages the game logic
  void startGame() {
    gameHasStarted = true;
    Timer.periodic(Duration(milliseconds: 60), (timer) {
      time += 0.05;
      height = -4.9 * time * time + 2.8 * time;

      setState(() {
        ballY = initialHeight - height;

        if (ballY > 1) {
          timer.cancel();
          gameHasStarted = false;
          resetGame();  // Auto-restart the game when the player loses
        }

        obstacleX -= 0.05;

        // If the obstacle goes off the screen, reset its position and change its color
        if (obstacleX < -1.5) {
          obstacleX = 1.5;
          obstacleColor = colors[Random().nextInt(4)];
          score += 1;  // Increment score for passing the obstacle
        }

        // Check for collision
        if (obstacleX < 0.05 && obstacleX > -0.05) {
          if (ballColor != obstacleColor) {
            timer.cancel();
            gameHasStarted = false;
            resetGame();  // Auto-restart the game when the player loses
          }
        }
      });
    });
  }

  // Function to change ball color when screen is tapped
  void changeColor() {
    setState(() {
      ballColor = colors[Random().nextInt(4)];
    });
  }

  // Reset game to initial state and restart the game automatically
  void resetGame() {
    setState(() {
      ballY = 0;
      obstacleX = 1.5;
      score = 0;
      ballColor = Colors.blue;
      obstacleColor = colors[Random().nextInt(4)];
      gameHasStarted = false;
    });
    startGame();  // Automatically restart the game after reset
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (gameHasStarted) {
          jump();
          changeColor();  // Change the color of the ball with each jump
        } else {
          startGame();
        }
      },
      child: Scaffold(
        body: Column(
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Stack(
                children: [
                  AnimatedContainer(
                    alignment: Alignment(0, ballY),
                    duration: Duration(milliseconds: 0),
                    color: Colors.blueAccent,
                    child: Ball(ballColor: ballColor),  // Ball widget with dynamic color
                  ),
                  AnimatedContainer(
                    alignment: Alignment(obstacleX, 1),
                    duration: Duration(milliseconds: 0),
                    child: Obstacle(obstacleColor: obstacleColor),
                  ),
                  Container(
                    alignment: Alignment(0, -0.5),
                    child: gameHasStarted
                        ? Text("")
                        : Text(
                      "TAP TO PLAY",
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                color: Colors.brown,
                child: Center(
                  child: Text(
                    "SCORE: $score",
                    style: TextStyle(fontSize: 35, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Ball extends StatelessWidget {
  final Color ballColor;
  Ball({required this.ballColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 50,
      decoration: BoxDecoration(
        color: ballColor,
        shape: BoxShape.circle,
      ),
    );
  }
}

class Obstacle extends StatelessWidget {
  final Color obstacleColor;
  Obstacle({required this.obstacleColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: 50,
      decoration: BoxDecoration(
        color: obstacleColor,
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }
}

