import 'package:flutter/material.dart';

class NotificationSettingsPage extends StatefulWidget {
  @override
  _NotificationSettingsPageState createState() => _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  bool isPushNotificationsEnabled = true;
  bool isEmailNotificationsEnabled = false;
  bool isSmsNotificationsEnabled = false;
  bool isPromotionalNotificationsEnabled = true;
  bool isMessageNotificationsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notification Settings")),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          // Push Notifications
          SwitchListTile(
            title: Text("Push Notifications"),
            subtitle: Text("Receive notifications on your device"),
            value: isPushNotificationsEnabled,
            onChanged: (value) {
              setState(() {
                isPushNotificationsEnabled = value;
              });
            },
          ),
          Divider(),

          // Email Notifications
          SwitchListTile(
            title: Text("Email Notifications"),
            subtitle: Text("Receive notifications via email"),
            value: isEmailNotificationsEnabled,
            onChanged: (value) {
              setState(() {
                isEmailNotificationsEnabled = value;
              });
            },
          ),
          Divider(),

          // SMS Notifications
          SwitchListTile(
            title: Text("SMS Notifications"),
            subtitle: Text("Receive notifications via SMS"),
            value: isSmsNotificationsEnabled,
            onChanged: (value) {
              setState(() {
                isSmsNotificationsEnabled = value;
              });
            },
          ),
          Divider(),

          // Promotional Notifications
          SwitchListTile(
            title: Text("Promotional Notifications"),
            subtitle: Text("Receive promotional content and offers"),
            value: isPromotionalNotificationsEnabled,
            onChanged: (value) {
              setState(() {
                isPromotionalNotificationsEnabled = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
