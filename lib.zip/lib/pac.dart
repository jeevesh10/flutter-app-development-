import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(DotJoiningGame());
}

class DotJoiningGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dot Joining Game',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

// Home screen widget with a Start button
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dot Joining Game'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => GameScreen()),
            );
          },
          child: Text('Start Game'),
        ),
      ),
    );
  }
}

// GameScreen to play the dot joining game
class GameScreen extends StatefulWidget {
  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  List<Offset> _dots = [];
  List<Offset> _connectedDots = [];
  List<Color> _dotColors = [];
  List<Offset> _lines = [];
  int _bestScore = 0;
  int _currentScore = 0;

  @override
  void initState() {
    super.initState();
    _generateDots();
  }

  // Generate pairs of dots with different colors
  void _generateDots() {
    _dots.clear();
    _dotColors.clear();
    Random random = Random();

    // Create 5 pairs of dots
    for (int i = 0; i < 5; i++) {
      Color dotColor = Colors.primaries[random.nextInt(Colors.primaries.length)];

      for (int j = 0; j < 2; j++) {
        Offset dot;
        do {
          dot = Offset(random.nextDouble() * 300, random.nextDouble() * 500);
        } while (_dots.contains(dot)); // Ensure unique dot positions

        _dots.add(dot);
        _dotColors.add(dotColor);
      }
    }

    setState(() {});
  }

  // Check if the tapped dot is already connected
  void _checkDot(Offset tapPosition) {
    for (int i = 0; i < _dots.length; i++) {
      Offset dot = _dots[i];
      if ((tapPosition - dot).distance < 20) {
        if (!_connectedDots.contains(dot)) {
          setState(() {
            _connectedDots.add(dot);
            _currentScore++;
            _lines.add(dot); // Add the dot to the lines list
          });
          // Check if the connected dots form a pair
          if (_connectedDots.length % 2 == 0) {
            _lines.add(_connectedDots[_connectedDots.length - 2]); // Add the last connected dot
          }
          if (_currentScore == 20) {
            _showWinDialog();
          }
          return;
        } else {
          _showGameOverDialog();
          return;
        }
      }
    }
  }

  // Show Game Over dialog
  void _showGameOverDialog() {
    if (_currentScore > _bestScore) {
      _bestScore = _currentScore;
    }
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
            title: Text('Game Over'),
            content: Text('You overlapped a dot! Your score: $_currentScore\nBest Score: $_bestScore'),
            actions: [
            TextButton(
            onPressed: () {
          Navigator.of(context).pop();
          _resetGame();
        },
        child: Text('Play Again'),
        ),
        TextButton(
        onPressed: () {
        Navigator.of(context).pop();
        Navigator.pop(context);
        },
        child: Text('Exit to Home'),
        ),
      ],
    );
  },
  );
}

// Show Win dialog when all dots are connected
void _showWinDialog() {
  if (_currentScore > _bestScore) {
    _bestScore = _currentScore;
  }
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
          title: Text('Congratulations!'),
          content: Text('You connected all dots! Your score: $_currentScore\nBest Score: $_bestScore'),
          actions: [
          TextButton(
          onPressed: () {
        Navigator.of(context).pop();
        _resetGame();
      },
      child: Text('Play Again'),
      ),
      TextButton(
      onPressed: () {
      Navigator.of(context).pop();
      Navigator.pop(context);
      },
      child: Text('Exit to Home'),
      ),
    ],
  );
},
);
}

// Reset the game
void _resetGame() {
  _connectedDots.clear();
  _lines.clear();
  _currentScore = 0;
  _generateDots();
}

@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text('Dot Joining Game'),
    ),
    body: GestureDetector(
      onTapDown: (details) {
        _checkDot(details.localPosition);
      },
      child: Stack(
        children: [
          CustomPaint(
            size: Size(double.infinity, double.infinity),
            painter: DotPainter(_dots, _connectedDots, _dotColors, _lines),
          ),
          Center(
            child: Text(
              'Tap to connect dots!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    ),
  );
}
}

// Custom painter to draw dots and lines
class DotPainter extends CustomPainter {
  final List<Offset> dots;
  final List<Offset> connectedDots;
  final List<Color> dotColors;
  final List<Offset> lines;

  DotPainter(this.dots, this.connectedDots, this.dotColors, this.lines);

  @override
  void paint(Canvas canvas, Size size) {
    // Draw lines between connected pairs of dots
    Paint linePaint = Paint()
      ..color = Colors.black
      ..strokeWidth = 3.0;

    for (int i = 0; i < lines.length; i += 2) {
      if (i + 1 < lines.length) {
        canvas.drawLine(lines[i], lines[i + 1], linePaint);
      }
    }

    // Draw the dots
    for (int i = 0; i < dots.length; i++) {
      Paint paint = Paint()
        ..color = dotColors[i]
        ..style = PaintingStyle.fill;

      canvas.drawCircle(dots[i], 20, paint);
    }

    // Draw connected dots
    Paint connectedPaint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    for (Offset dot in connectedDots) {
      canvas.drawCircle(dot, 20, connectedPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
