import 'package:flutter/material.dart';

void main() {
  runApp(PopItFidgetGame());
}

class PopItFidgetGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pop It Fidget Game',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: GamePage(),
    );
  }
}

class GamePage extends StatefulWidget {
  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  // Grid of bubbles, each represented by a boolean (false = unpopped, true = popped)
  List<List<bool>> grid = List.generate(5, (index) => List.generate(5, (index) => false));

  // Function to handle bubble tap
  void popBubble(int row, int col) {
    setState(() {
      grid[row][col] = true;  // Set the bubble as popped
    });
  }

  // Function to reset all bubbles
  void resetGame() {
    setState(() {
      grid = List.generate(5, (index) => List.generate(5, (index) => false)); // Reset all bubbles to unpopped state
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pop It Fidget Game'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: resetGame,  // Reset button in the app bar
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(20.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,  // 5x5 grid of bubbles
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: 25,  // 5 rows * 5 columns = 25 bubbles
              itemBuilder: (context, index) {
                int row = index ~/ 5;
                int col = index % 5;
                return GestureDetector(
                  onTap: () {
                    if (!grid[row][col]) {
                      popBubble(row, col);  // Only pop unpopped bubbles
                    }
                  },
                  child: Bubble(isPopped: grid[row][col]),  // Pass the pop state of the bubble
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: resetGame,  // Reset button at the bottom
              child: Text('Reset'),
            ),
          ),
        ],
      ),
    );
  }
}

class Bubble extends StatelessWidget {
  final bool isPopped;
  Bubble({required this.isPopped});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isPopped ? Colors.grey[300] : Colors.blue,  // Change color when popped
        boxShadow: [
          if (!isPopped)
            BoxShadow(
              color: Colors.black26,
              blurRadius: 10.0,
              spreadRadius: 2.0,
              offset: Offset(4.0, 4.0),  // Shadow for unpopped bubbles
            ),
        ],
      ),
    );
  }
}
