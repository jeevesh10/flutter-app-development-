import 'package:flutter/material.dart';
import 'language.dart';
import 'edit.dart';
import 'privacy.dart';
import 'mnp.dart';
import 'ians.dart';
import 'clearcache.dart';

void main() {
  runApp(SettingsApp());
}

class SettingsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Settings',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Settings(),
    );
  }
}

class Settings extends StatefulWidget {
  @override
  _SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  bool isDarkMode = false;
  bool notificationsEnabled = true;
  bool highContrastMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: ListView(
        children: [
          // Account Settings
          buildAccountSettingsSection(),
          Divider(),

          // Notifications
          buildNotificationsSection(),
          Divider(),

          // Language & Region
          buildLanguageRegionSection(),
          Divider(),

          // Data & Storage
          buildDataStorageSection(),
          Divider(),

          // Accessibility
        ],
      ),
    );
  }

  Widget buildAccountSettingsSection() {
    return ExpansionTile(
      title: Text('Account Settings'),
      children: [
        ListTile(
          title: Text('Edit Profile'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => EditProfile()),
            );
            // Handle profile editing
          },
        ),

        ListTile(
          title: Text('Privacy Settings'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => PrivacySettingsPage()),
            ); // Handle privacy settings
          },
        ),
      ],
    );
  }

  Widget buildNotificationsSection() {
    return ExpansionTile(
      title: Text('Notifications'),
      children: [
        SwitchListTile(
          title: Text('Enable Notifications'),
          value: notificationsEnabled,
          onChanged: (bool value) {
            setState(() {
              notificationsEnabled = value;
            });
          },
        ),
        ListTile(
          title: Text('Manage Notification Preferences'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => NotificationSettingsPage()),
            );
            // Manage sound/vibration preferences
          },
        ),
        ListTile(
          title: Text('In-App Notification Settings'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => InAppNotificationSettingsPage()),
            );
            // Handle in-app notifications
          },
        ),
      ],
    );
  }

  Widget buildLanguageRegionSection() {
    return ExpansionTile(
      title: Text('Language'),
      children: [
        ListTile(
          title: Text('Language Options'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => MyApp()),
            );
            // Change language
          },
        ),
      ],
    );
  }

  Widget buildDataStorageSection() {
    return ExpansionTile(
      title: Text('Data & Storage'),
      children: [
        ListTile(
          title: Text('Clear Cache'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ClearCachePage()),
            ); // Clear app cache
          },
        ),
      ],
    );
  }
}
