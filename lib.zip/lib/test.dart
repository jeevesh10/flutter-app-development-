import 'package:flutter/material.dart';

void main() {
  runApp(AnxietyTestApp());
}

class AnxietyTestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Anxiety Test',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: UserInfoPage(),
    );
  }
}

class UserInfoPage extends StatefulWidget {
  @override
  _UserInfoPageState createState() => _UserInfoPageState();
}

class _UserInfoPageState extends State<UserInfoPage> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  int? _age; // Use nullable int for dropdown
  String _occupation = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Anxiety Test - User Information'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Name'),
                onSaved: (value) {
                  _name = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<int>(
                decoration: InputDecoration(labelText: 'Age'),
                items: List.generate(101, (index) {
                  return DropdownMenuItem<int>(
                    value: index,
                    child: Text(index.toString()),
                  );
                }),
                onChanged: (value) {
                  setState(() {
                    _age = value;
                  });
                },
                onSaved: (value) {
                  _age = value!;
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select your age';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Occupation'),
                onSaved: (value) {
                  _occupation = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your occupation';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AnxietyTestPage(
                          name: _name,
                          age: _age!,
                          occupation: _occupation,
                        ),
                      ),
                    );
                  }
                },
                child: Text('Start Test'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AnxietyTestPage extends StatefulWidget {
  final String name;
  final int age;
  final String occupation;

  AnxietyTestPage({required this.name, required this.age, required this.occupation});

  @override
  _AnxietyTestPageState createState() => _AnxietyTestPageState();
}

class _AnxietyTestPageState extends State<AnxietyTestPage> {
  int _currentQuestionIndex = 0;
  int _totalScore = 0;

  final List<Map<String, Object>> _questions = [
    {
      'questionText': 'How often do you feel nervous or anxious without a clear reason?',
      'answers': [
        {'text': 'Almost never', 'score': 1},
        {'text': 'Occasionally', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Almost always', 'score': 4},
      ],
    },
    {
      'questionText': 'Do you find it difficult to control your worry or stop thinking about what makes you anxious?',
      'answers': [
        {'text': 'Never', 'score': 1},
        {'text': 'Sometimes', 'score': 2},
        {'text': 'Often', 'score': 3},
        {'text': 'Almost always', 'score': 4},
      ],
    },
    {
      'questionText': 'When feeling anxious, do you experience physical symptoms (e.g., rapid heartbeat, sweating, shaking)?',
      'answers': [
        {'text': 'Rarely or never', 'score': 1},
        {'text': 'Sometimes', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Almost all the time', 'score': 4},
      ],
    },
    {
      'questionText': 'How often do you avoid situations because they make you feel anxious?',
      'answers': [
        {'text': 'Almost never', 'score': 1},
        {'text': 'Occasionally', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Very frequently', 'score': 4},
      ],
    },
    {
      'questionText': 'Do you worry excessively about things that are unlikely to happen?',
      'answers': [
        {'text': 'Never', 'score': 1},
        {'text': 'Occasionally', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Almost all the time', 'score': 4},
      ],
    },
    {
      'questionText': 'Do you find it hard to relax when you feel anxious?',
      'answers': [
        {'text': 'Never', 'score': 1},
        {'text': 'Sometimes', 'score': 2},
        {'text': 'Often', 'score': 3},
        {'text': 'Almost always', 'score': 4},
      ],
    },
    {
      'questionText': 'How often do you feel like something bad will happen?',
      'answers': [
        {'text': 'Rarely', 'score': 1},
        {'text': 'Occasionally', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Almost always', 'score': 4},
      ],
    },
    {
      'questionText': 'Do you get irritable when feeling anxious?',
      'answers': [
        {'text': 'Never', 'score': 1},
        {'text': 'Sometimes', 'score': 2},
        {'text': 'Often', 'score': 3},
        {'text': 'Almost always', 'score': 4},
      ],
    },
    {
      'questionText': 'Do you struggle with sleep due to anxious thoughts?',
      'answers': [
        {'text': 'Rarely', 'score': 1},
        {'text': 'Occasionally', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Almost all the time', 'score': 4},
      ],
    },
    {
      'questionText': 'Do you find it hard to focus due to anxiety?',
      'answers': [
        {'text': 'Never', 'score': 1},
        {'text': 'Sometimes', 'score': 2},
        {'text': 'Frequently', 'score': 3},
        {'text': 'Almost all the time', 'score': 4},
      ],
    },
  ];

  void _answerQuestion(int score) {
    _totalScore += score;

    setState(() {
      _currentQuestionIndex++;
    });

    if (_currentQuestionIndex >= _questions.length) {
      _showResult();
    }
  }

  String get resultText {
    if (_totalScore <= 10) {
      return 'Low anxiety – You rarely feel anxious.';
    } else if (_totalScore <= 20) {
      return 'Mild anxiety – You sometimes feel anxious.';
    } else if (_totalScore <= 30) {
      return 'Moderate anxiety – You frequently feel anxious.';
    } else {
      return 'High anxiety – You experience significant anxiety.';
    }
  }

  void _showResult() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Test Completed!'),
        content: Text(
          'Name: ${widget.name}\nAge: ${widget.age}\nOccupation: ${widget.occupation}\n\nYour Score: $_totalScore\n$resultText',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              setState(() {
                _currentQuestionIndex = 0;
                _totalScore = 0;
              });
            },
            child: Text('Retake Test'),
          ),
          TextButton(
            onPressed: () {
              // Return to the home page
              Navigator.popUntil(ctx, (route) => route.isFirst);
            },
            child: Text('Exit'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Anxiety Test'),
      ),
      body: _currentQuestionIndex < _questions.length
          ? Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Text(
              _questions[_currentQuestionIndex]['questionText'] as String,
              style: TextStyle(fontSize: 20.0),
              textAlign: TextAlign.center,
            ),
          ),
          ...(_questions[_currentQuestionIndex]['answers'] as List<Map<String, Object>>).map((answer) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: ElevatedButton(
                onPressed: () => _answerQuestion(answer['score'] as int),
                child: Text(answer['text'] as String),
              ),
            );
          }).toList(),
        ],
      )
          : Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
