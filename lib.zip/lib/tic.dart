import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: LoginPage(
        onLogin: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => HomePage(
                  onThemeChanged: (value) {
                    setState(() {
                      isDarkMode = value;
                    });
                  },
                )),
          );
        },
      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  final VoidCallback onLogin;

  LoginPage({required this.onLogin});

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Replace with actual authentication logic
                if (usernameController.text.isNotEmpty &&
                    passwordController.text.isNotEmpty) {
                  onLogin();
                }
              },
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final Function(bool) onThemeChanged;

  HomePage({required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Menu',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              title: Text('Settings'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SettingsPage()),
                );
              },
            ),
            ListTile(
              title: Text('Theme Change'),
              onTap: () {
                // Toggle dark/light theme
                bool currentTheme = Theme.of(context).brightness == Brightness.dark;
                onThemeChanged(!currentTheme);
                Navigator.of(context).pop(); // Close the drawer
              },
            ),
            ListTile(
              title: Text('Log Out'),
              onTap: () {
                // Handle logout
                Navigator.of(context).pop(); // Close the drawer
              },
            ),
            ListTile(
              title: Text('Exit'),
              onTap: () {
                // Handle exit
                Navigator.of(context).pop(); // Close the drawer
              },
            ),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => TicTacToePage()),
                  );
                },
                child: Container(
                  width: 100,
                  height: 100,
                  color: Colors.blue,
                  child: Center(child: Text('Game', style: TextStyle(color: Colors.white))),
                ),
              ),
              GestureDetector(
                onTap: () {
                  // Navigate to another page for "Test"
                },
                child: Container(
                  width: 100,
                  height: 100,
                  color: Colors.green,
                  child: Center(child: Text('Test', style: TextStyle(color: Colors.white))),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Center(
        child: Text('Settings Page'),
      ),
    );
  }
}

class TicTacToePage extends StatefulWidget {
  @override
  _TicTacToePageState createState() => _TicTacToePageState();
}

class _TicTacToePageState extends State<TicTacToePage> {
  List<String> board = List.filled(9, '');
  bool isPlayerTurn = true;
  String currentPlayer = 'X';
  String winner = '';
  double difficultyLevel = 0.0; // 0.0 - Easy, 1.0 - Medium, 2.0 - Hard
  String playerSymbol = 'X'; // Default player symbol

  @override
  void initState() {
    super.initState();
    resetBoard();
  }

  void resetBoard() {
    setState(() {
      board = List.filled(9, '');
      currentPlayer = playerSymbol;
      isPlayerTurn = true;
      winner = '';
    });
  }

  void makeMove(int index) {
    if (board[index] == '' && winner == '') {
      setState(() {
        board[index] = currentPlayer;
        isPlayerTurn = !isPlayerTurn;
        checkWinner();

        if (!isPlayerTurn && winner == '') {
          computerMove();
        }
      });
    }
  }

  void computerMove() async {
    await Future.delayed(Duration(milliseconds: 500)); // Delay for a more natural feeling

    int index;
    if (difficultyLevel == 0.0) {
      index = _easyMove();
    } else if (difficultyLevel == 1.0) {
      index = _mediumMove();
    } else {
      index = _hardMove();
    }

    if (index != -1) {
      setState(() {
        board[index] = currentPlayer == 'X' ? 'O' : 'X';
        isPlayerTurn = !isPlayerTurn;
        checkWinner();
      });
    }
  }

  int _easyMove() {
    List<int> availableSpots = [];
    for (int i = 0; i < board.length; i++) {
      if (board[i] == '') availableSpots.add(i);
    }
    if (availableSpots.isNotEmpty) {
      return availableSpots[Random().nextInt(availableSpots.length)];
    }
    return -1;
  }

  int _mediumMove() {
    // Block the player from winning
    int playerMove = _findWinningMove(currentPlayer);
    if (playerMove != -1) {
      return playerMove;
    } else {
      return _easyMove();
    }
  }

  int _hardMove() {
    // Use minimax to calculate the best move
    return _minimax('O')['index'] ?? -1; // Ensure to return -1 if no best move is found
  }

  Map<String, dynamic> _minimax(String currentPlayer) {
    List<int> availableSpots = [];
    for (int i = 0; i < board.length; i++) {
      if (board[i] == '') availableSpots.add(i);
    }

    if (_checkWinner('X')) {
      return {'score': -10};
    } else if (_checkWinner('O')) {
      return {'score': 10};
    } else if (availableSpots.isEmpty) {
      return {'score': 0};
    }

    List<Map<String, dynamic>> moves = [];
    Map<String, dynamic> bestMove = {'score': currentPlayer == 'O' ? -1000 : 1000}; // Initialize best move with extreme score

    for (int i = 0; i < availableSpots.length; i++) {
      int index = availableSpots[i];
      board[index] = currentPlayer;

      Map<String, dynamic> result;
      if (currentPlayer == 'O') {
        result = _minimax('X');
        if (result['score'] > bestMove['score']) {
          bestMove = result..['index'] = index; // Store the index of the best move
        }
      } else {
        result = _minimax('O');
        if (result['score'] < bestMove['score']) {
          bestMove = result..['index'] = index; // Store the index of the best move
        }
      }
      board[index] = ''; // Undo the move
    }

    return bestMove;
  }

  int _findWinningMove(String player) {
    for (int i = 0; i < board.length; i++) {
      if (board[i] == '') {
        board[i] = player;
        bool isWinning = _checkWinner(player);
        board[i] = '';
        if (isWinning) {
          return i;
        }
      }
    }
    return -1;
  }

  bool _checkWinner(String player) {
    List<List<int>> winningCombinations = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];

    for (var combination in winningCombinations) {
      if (board[combination[0]] == player &&
          board[combination[1]] == player &&
          board[combination[2]] == player) {
        return true;
      }
    }
    return false;
  }

  void checkWinner() {
    if (_checkWinner('X')) {
      winner = 'Player X won!';
    } else if (_checkWinner('O')) {
      winner = 'Computer O won!';
    } else if (!board.contains('')) {
      winner = 'It\'s a draw!';
    }

    if (winner != '') {
      _showGameOverDialog(winner);
    }
  }

  void _showGameOverDialog(String winner) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Game Over'),
        content: Text(winner),
        actions: [
          TextButton(
            child: Text('Play Again'),
            onPressed: () {
              resetBoard();
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tic-Tac-Toe'),
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
              ),
              itemCount: 9,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: isPlayerTurn ? () => makeMove(index) : null,
                  child: Container(
                    margin: EdgeInsets.all(4.0),
                    color: Colors.blue[50],
                    child: Center(
                      child: Text(
                        board[index],
                        style: TextStyle(
                          fontSize: 40.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          if (winner.isEmpty)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Current Player: $currentPlayer',
                style: TextStyle(fontSize: 24),
              ),
            ),
          // Player symbol selection slider
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Play as: '),
              Slider(
                value: playerSymbol == 'X' ? 0.0 : 1.0,
                min: 0.0,
                max: 1.0,
                divisions: 1,
                label: playerSymbol,
                onChanged: (value) {
                  setState(() {
                    playerSymbol = value == 0.0 ? 'X' : 'O';
                    resetBoard(); // Reset the game when the player changes symbol
                  });
                },
              ),
              Text(playerSymbol),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Difficulty Level: ${difficultyLevel == 0.0 ? 'Easy' : difficultyLevel == 1.0 ? 'Medium' : 'Hard'}',
              style: TextStyle(fontSize: 18),
            ),
          ),
          Slider(
            value: difficultyLevel,
            min: 0.0,
            max: 2.0,
            divisions: 2,
            label: difficultyLevel == 0.0
                ? 'Easy'
                : difficultyLevel == 1.0
                ? 'Medium'
                : 'Hard',
            onChanged: (value) {
              setState(() {
                difficultyLevel = value;
              });
            },
          ),
        ],
      ),
    );
  }
}


