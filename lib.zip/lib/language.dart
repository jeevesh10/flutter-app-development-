import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'app_localizations.dart'; // Make sure this import points to your AppLocalizations file

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale _locale = Locale('en');

  void _changeLanguage(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      locale: _locale,
      supportedLocales: [
        Locale('en', ''),
        Locale('hi', ''),
        Locale('mr', ''),
        Locale('ta', ''),
        Locale('te', ''),
        Locale('es', ''),
        Locale('fr', ''),
        Locale('de', ''),
      ],
      localizationsDelegates: [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: HomeScreen(onLocaleChange: _changeLanguage),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final Function(Locale) onLocaleChange;

  HomeScreen({required this.onLocaleChange});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)?.translate('title') ?? ''),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(AppLocalizations.of(context)?.translate('greeting') ?? ''),
            DropdownButton<Locale>(
              hint: Text(AppLocalizations.of(context)?.translate('languageSelection') ?? ''),
              onChanged: (Locale? newLocale) {
                if (newLocale != null) {
                  onLocaleChange(newLocale);
                }
              },
              items: [
                Locale('en', ''),
                Locale('hi', ''),
                Locale('mr', ''),
                Locale('ta', ''),
                Locale('te', ''),
                Locale('es', ''),
                Locale('fr', ''),
                Locale('de', ''),
              ].map<DropdownMenuItem<Locale>>((Locale locale) {
                return DropdownMenuItem<Locale>(
                  value: locale,
                  child: Text(locale.languageCode.toUpperCase()),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
