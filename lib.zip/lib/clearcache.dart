import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class ClearCachePage extends StatefulWidget {
  @override
  _ClearCachePageState createState() => _ClearCachePageState();
}

class _ClearCachePageState extends State<ClearCachePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  bool _isSpinning = false;
  String _cacheSize = 'Calculating...';

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    _getCacheSize();
  }

  Future<void> clearCache() async {
    try {
      final cacheDir = await getTemporaryDirectory();
      if (cacheDir.existsSync()) {
        cacheDir.deleteSync(recursive: true);
      }
      print("Cache cleared successfully.");
      _getCacheSize(); // Update cache size after clearing
    } catch (e) {
      print("Error clearing cache: $e");
    }
  }

  Future<void> _getCacheSize() async {
    final cacheDir = await getTemporaryDirectory();
    final cacheSize = await _calculateSize(cacheDir);
    setState(() {
      _cacheSize = '${cacheSize / (1024 * 1024)} MB'; // Convert to MB
    });
  }

  Future<int> _calculateSize(Directory dir) async {
    int totalSize = 0;
    try {
      final List<FileSystemEntity> files = dir.listSync();
      for (var file in files) {
        if (file is File) {
          totalSize += await file.length();
        }
      }
    } catch (e) {
      print("Error calculating cache size: $e");
    }
    return totalSize;
  }

  void _onHamsterTapped() async {
    if (!_isSpinning) {
      setState(() {
        _isSpinning = true;
      });
      _controller.repeat();
      await clearCache();
      _controller.stop();
      setState(() {
        _isSpinning = false;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Clear Cache")),
      body: Center(
        child: GestureDetector(
          onTap: _onHamsterTapped,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Wheel Background
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [Colors.grey.withOpacity(0), Colors.grey],
                    stops: [0.478, 0.48],
                  ),
                ),
              ),
              // Hamster
              AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Transform.rotate(
                    angle: _isSpinning ? _controller.value * 2 * 3.14159 : 0,
                    child: Container(
                      width: 70,
                      height: 40,
                      child: Stack(
                        children: [
                          // Hamster Body
                          Positioned(
                            left: 15,
                            bottom: 10,
                            child: Container(
                              width: 40,
                              height: 25,
                              decoration: BoxDecoration(
                                color: Color(0xFFDAA520), // Hamster color
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          // Hamster Head
                          Positioned(
                            left: 10,
                            top: 0,
                            child: Container(
                              width: 15,
                              height: 15,
                              decoration: BoxDecoration(
                                color: Color(0xFFDAA520),
                                borderRadius: BorderRadius.circular(50),
                              ),
                            ),
                          ),
                          // Hamster Ear
                          Positioned(
                            left: 2,
                            top: 2,
                            child: Container(
                              width: 5,
                              height: 5,
                              decoration: BoxDecoration(
                                color: Color(0xFFE0B0FF),
                                borderRadius: BorderRadius.circular(50),
                              ),
                            ),
                          ),
                          // Hamster Eye
                          Positioned(
                            left: 12,
                            top: 3,
                            child: Container(
                              width: 3,
                              height: 3,
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(50),
                              ),
                            ),
                          ),
                          // Hamster Tail
                          Positioned(
                            right: 0,
                            top: 10,
                            child: Container(
                              width: 10,
                              height: 3,
                              decoration: BoxDecoration(
                                color: Color(0xFFDAA520),
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(16),
        child: Text(
          'Cache Size: $_cacheSize',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
